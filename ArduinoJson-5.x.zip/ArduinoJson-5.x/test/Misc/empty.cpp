// ArduinoJson - arduinojson.org
// Copyright Benoit Blanchon 2014-2019
// MIT License

// catch.hpp mutes several warnings, this file allows to detect them

#include "ArduinoJson.h"
